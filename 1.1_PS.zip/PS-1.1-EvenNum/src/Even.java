import java.util.Scanner;

public class Even {

	public static void main(String[] args) {
		
		int i, num;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter value n: ");
		
		num = sc.nextInt();
		
		for(i=0; i<=num; i++) {
			
			if(i%2==0)
				System.out.println(i+"\n");
		

	}
	}
}
