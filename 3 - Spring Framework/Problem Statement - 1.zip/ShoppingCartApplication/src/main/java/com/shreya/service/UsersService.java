package com.shreya.service;

import com.shreya.model.Users;

public interface UsersService {

public void addUsers(Users users);
	
	Users findUserByusername(String username);
}
