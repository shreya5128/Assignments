package com.shreya.service;

import java.util.List;

import com.shreya.model.Cart;
import com.shreya.model.CartItem;

public interface CartItemService {

public void addCartItem(CartItem cartItem);
	
	public void deleteCartItem(CartItem cartItem);
	
	
	public void removeAllCartItems(Cart cart);
	
	CartItem getCartItemByProduct(long productId);
	List<CartItem> findAllCartItemsBycart(Cart cart);
}
