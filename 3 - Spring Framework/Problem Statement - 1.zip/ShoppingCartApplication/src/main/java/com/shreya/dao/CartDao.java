package com.shreya.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.shreya.model.Cart;

@Repository
public interface CartDao extends CrudRepository<Cart, Long> {

	Cart findUserBycartId(long cartId);

	Cart findOne(long cartId);
}