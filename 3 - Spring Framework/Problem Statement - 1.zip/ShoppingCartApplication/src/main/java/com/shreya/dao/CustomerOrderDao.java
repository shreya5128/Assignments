package com.shreya.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.shreya.model.Cart;
import com.shreya.model.CustomerOrder;

@Repository
public interface CustomerOrderDao extends CrudRepository<CustomerOrder, Long>{

	CustomerOrder getCustomerOrderBycart(Cart cart);

	CustomerOrder findOne(long customerOrderId);

	void delete(long customerOrderId);
}
