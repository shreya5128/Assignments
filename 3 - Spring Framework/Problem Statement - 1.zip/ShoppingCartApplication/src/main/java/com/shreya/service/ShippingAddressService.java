package com.shreya.service;

import com.shreya.model.ShippingAddress;

public interface ShippingAddressService {

public void addShippingAddress(ShippingAddress shippingAddress);
	
	ShippingAddress getShippingAddressById(long shippingAddressId);
}
