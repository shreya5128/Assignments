package com.shreya.service;

import com.shreya.model.Authorities;

public interface AuthoritiesService {
public void addAuthorities(Authorities authorities);
	
	Authorities findAuthoritiesByusername(String username);
}
