package com.shreya.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.shreya.model.PersistentLogin;
@org.springframework.stereotype.Repository

public interface RememberMeTokenRepository extends CrudRepository<PersistentLogin, Long> {

	void delete(List<PersistentLogin> persistentLogins);

	PersistentLogin findBySeries(String seriesId);

	List<PersistentLogin> findByUsername(String username);

}
