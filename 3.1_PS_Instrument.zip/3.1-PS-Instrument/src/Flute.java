
public class Flute extends Instrument {

}
