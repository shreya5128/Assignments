
public class Piano extends Instrument {

}
