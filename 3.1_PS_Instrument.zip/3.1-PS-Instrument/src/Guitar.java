
public class Guitar extends Instrument {

}
